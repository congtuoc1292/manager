<?php

    return [
        'title_page' => 'Cài đặt giao diện'
    ];

?>
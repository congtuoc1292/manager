<?php

    namespace Librarys\Minify\Exceptions;

    if (defined('LOADED') == false)
        exit;

    use Librarys\Minify\Exception;
    /**
     * @author Matthias Mullie <minify@mullie.eu>
     */
    abstract class BasicException extends Exception
    {
    }

?>